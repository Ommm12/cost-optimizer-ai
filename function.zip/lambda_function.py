import json
import boto3
from cost_analyzer import get_cost

sns = boto3.client('sns')

TOPIC_ARN = "arn:aws:sns:us-east-1:584570449633:cost-alert"  # <-- replace if needed

def lambda_handler(event, context):
    data = get_cost()

    total_cost = 0
    for day in data['ResultsByTime']:
        total_cost += float(day['Total']['UnblendedCost']['Amount'])

    message = f"🚨 Weekly AWS Cost: ${total_cost:.2f}"

    print(message)

    # 🔥 Send email via SNS
    sns.publish(
        TopicArn=TOPIC_ARN,
        Message=message,
        Subject="AWS Cost Alert"
    )

    return {
        'statusCode': 200,
        'body': json.dumps(message)
    }